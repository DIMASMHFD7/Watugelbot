const daftarvip = (prefix) => { 
	return `
	
*HARGA DAFTAR VIP :*
-Rp. 5K > Akses Fitur ViP
-Rp. 10K > Fitur VIP + Masukin Bot KeGrup Kalian!

*JIKA INGIN DAFTAR VIP :*
*Chat Owner BOT :*
_wa.me/6282134055540 atau ketik *${prefix}owner*

*NOTE*

*GRUP [CCT]|<CROCODILE CYBER TEAM>| :*
_https://chat.whatsapp.com/GB37ZiXj0Fw1m13emtEqod_ `
}
exports.daftarvip = daftarvip