const kerangmenu = (prefix) => { 
	return `
╭┈─────𝙵𝙸𝚃𝚄𝚁 𝙽𝚈𝙰 CUK
╰─❁۪۪
╰─➤ *${prefix}apakah [optional]*
╰─➤ *${prefix}rate [optional]*
╰─➤ *${prefix}bisakah [optional]*
╰─➤ *${prefix}kapankah [optional]*
╰─➤ *${prefix}gantengcek*
╰─➤ *${prefix}toxic*
╰─➤ *${prefix}cantikcek*
╰─➤ *${prefix}persengay*
╭┈─────𝚝𝚑𝚊𝚗𝚡 𝚝𝚘 dimas mahfudiarto
╰─❁۪۪`
}
exports.kerangmenu = kerangmenu